package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ProductBean;
import model.ProductDAO;

public class ProductDAOJdbcTEST implements ProductDAO {
	public static void main(String[] args) {
//Select一筆資料
//		ProductDAOJdbc useselect=new ProductDAOJdbc();
//		ProductBean bean=useselect.select(1);
//		System.out.println(bean);
//Select多筆資料		
//		ProductDAOJdbc useselect=new ProductDAOJdbc();
//		List<ProductBean> result=useselect.select();
//		for (ProductBean bean : result) {
//			System.out.print(bean.getId() + ", ");
//			System.out.print(bean.getName() + ", ");
//			System.out.print(bean.getPrice() + ", ");
//			System.out.print(bean.getMake() + ", ");
//			System.out.print(bean.getExpire() + "\n");
//		}
//inset資料
		ProductDAOJdbcTEST useselect=new ProductDAOJdbcTEST();
		

		
	}
	private static final String URL = "jdbc:sqlserver://localhost:1433;database=java";
	private static final String USERNAME = "sa";
	private static final String PASSWORD = "sa123456";

	private static final String SELECT_BY_ID = "select * from product where id=?";
	@Override
	public ProductBean select(int id) {
		ProductBean result = null;
		ResultSet rs=null;
		try (Connection conn=DriverManager.getConnection(URL, USERNAME, PASSWORD);
				PreparedStatement pstm=conn.prepareStatement(SELECT_BY_ID);){			
				pstm.setInt(1, id);
				rs=pstm.executeQuery();
				 
				 if(rs.next()) {
					 result=new ProductBean();
					 result.setId(rs.getInt(1));
					 result.setName(rs.getString(2));
					 result.setPrice(rs.getFloat(3));					
					 result.setMake(rs.getDate(4));
					 result.setExpire(rs.getInt(5));
				 }
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			if(rs !=null) {
				
			
			try {
				rs.close();
			} catch (SQLException e) {							
			}
			}
		}
		
		return result;
	}
	
	private static final String SELECT_ALL = "select * from product";
	@Override
	public List<ProductBean> select() {
		ProductBean result=null;
		List<ProductBean> results = new ArrayList<ProductBean>();
		
		ResultSet rs=null;		
		try (Connection conn=DriverManager.getConnection(URL, USERNAME, PASSWORD);
			PreparedStatement pstm =conn.prepareStatement(SELECT_ALL);){
     			 rs=pstm.executeQuery();
     			
     			while(rs.next()) {
     				result=new ProductBean();
     				result.setId(rs.getInt(1));
     				result.setName(rs.getString(2));
     				result.setPrice(rs.getFloat(3));
     				result.setMake(rs.getDate(4));
     				result.setExpire(rs.getInt(5));
     				results.add(result);
     			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			if(rs !=null) {
				
			
			try {
				rs.close();
			} catch (SQLException e) {							
			}
			}
		}
		
		return results;
	}
	
	private static final String INSERT =
			"insert into product (id, name, price, make, expire) values (?, ?, ?, ?, ?)";
	@Override
	public ProductBean insert(ProductBean bean) {
		ProductBean result = null;
			
		try (Connection conn=DriverManager.getConnection(URL, USERNAME, PASSWORD);
			PreparedStatement pstm =conn.prepareStatement(INSERT);){
			result=new ProductBean();
			pstm.setInt(1, bean.getId());
			result.setId(bean.getId());
			pstm.setString(2, bean.getName());
			result.setName(bean.getName());
      			Double temp=new Double(bean.getPrice());
      		result.setPrice(bean.getPrice());
     			pstm.setFloat(3,temp.floatValue());
     			long time=bean.getMake().getTime();
//     		result.setMake(bean.getMake().getTime());
     			pstm.setDate(4, new java.sql.Date(time));
     			pstm.setInt(5, bean.getExpire());
     			
					 
				 
     			
     			
     			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}								
		return result;
	}
	
	private static final String UPDATE =
			"update product set name=?, price=?, make=?, expire=? where id=?";
	@Override
	public ProductBean update(String name,
			double price, java.util.Date make, int expire, int id) {
		ProductBean result = null;

		return result;
	}
	
	private static final String DELETE = "delete from product where id=?";
	@Override
	public boolean delete(int id) {

		return false;
	}
}
