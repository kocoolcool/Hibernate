package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.ProductBean;
import model.ProductDAO;

public class ProductDAOJdbcBK implements ProductDAO {
//	private static final String URL = "jdbc:sqlserver://localhost:1433;database=Maven";
//	private static final String USERNAME = "sa";
//	private static final String PASSWORD = "123456";

	
	public static void main(String[] args) {
//		ProductBean productbean = new ProductBean();
//		productbean = new ProductDAOJdbc().select(1);
//		System.out.println(productbean);
//		ProductBean insert = new ProductBean();
//		insert.setId(12);insert.setName("ABC");insert.setPrice((double) 50);insert.setMake(new java.sql.Date(0));
//		insert.setExpire(50);
//		productbean = new ProductDAOJdbc().insert(insert);
//		System.out.println(productbean);
		
//		System.out.println(new ProductDAOJdbc().select());

	}

	private static final String SELECT_BY_ID = "select * from product where id=?";

	
	
	public DataSource ds= null;
	public ProductDAOJdbcBK() {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public ProductBean select(int id) {
		ProductBean result = null;
		ResultSet rs = null;
		try (
//				Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
				Connection conn = ds.getConnection();
				PreparedStatement pstm = conn.prepareStatement(SELECT_BY_ID);) {
			pstm.setInt(1, id);
			rs = pstm.executeQuery();
			while (rs.next()) {
				result = new ProductBean();
				result.setId(rs.getInt(1));
				result.setName(rs.getString(2));
				result.setPrice(rs.getDouble(3));
				result.setMake(rs.getDate(4));
				result.setExpire(rs.getInt(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return result;
	}

	private static final String SELECT_ALL = "select * from product";

	@Override
	public List<ProductBean> select() {
		List<ProductBean> result = new ArrayList<ProductBean>();
		
		ResultSet rs=null;
		try(
//			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			Connection conn = ds.getConnection();
			PreparedStatement pstm = conn.prepareStatement(SELECT_ALL);) {
			rs = pstm.executeQuery();
			while(rs.next()){
			   ProductBean pb = new ProductBean();
			   pb.setId(rs.getInt(1));
			   pb.setName(rs.getString(2));
			   pb.setPrice(rs.getDouble(3));
		       pb.setMake(rs.getDate(4));
		       pb.setExpire(rs.getInt(5));
		       result.add(pb);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			
			if (rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {

					e.printStackTrace();
				} 
			}
		}
		return result;
	}

	private static final String INSERT = "insert into product (id, name, price, make, expire) values (?, ?, ?, ?, ?)";

	@Override
	public ProductBean insert(ProductBean bean) {
		ProductBean result = null;
		try (
//			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			Connection conn = ds.getConnection();
			PreparedStatement pstm = conn.prepareStatement(INSERT);) {
			pstm.setInt(1, bean.getId());
			pstm.setString(2, bean.getName());
			pstm.setDouble(3, bean.getPrice());

			if (bean.getMake() != null) {
				long tamp = bean.getMake().getTime();
				pstm.setDate(4, new java.sql.Date(tamp));
			} else {
				pstm.setDate(4, null);
			}
			pstm.setInt(5, bean.getExpire());

			int i = pstm.executeUpdate();
			if (i == 1) {
				result = bean;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	private static final String UPDATE = "update product set name=?, price=?, make=?, expire=? where id=?";

	@Override
	public ProductBean update(String name, double price, java.util.Date make, int expire, int id) {
		ProductBean result = null;
		try (
//			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			Connection conn = ds.getConnection();
			PreparedStatement pstm = conn.prepareStatement(UPDATE);) {

			pstm.setString(1, name);
			pstm.setDouble(2, price);
			if (make !=null) {
				long tamp = make.getTime();
				pstm.setDate(3, new java.sql.Date(tamp));
			}else {
				pstm.setDate(3, null);
			}
			pstm.setInt(4, expire);
			pstm.setInt(5, id);
			pstm.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return result;
	}

	private static final String DELETE = "delete from product where id=?";

	@Override
	public boolean delete(int id) {
		try (
//			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			Connection conn = ds.getConnection();
			PreparedStatement pstm = conn.prepareStatement(DELETE);) {

			pstm.setInt(1, id);
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
}
